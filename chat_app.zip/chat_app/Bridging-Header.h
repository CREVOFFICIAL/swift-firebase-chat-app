//
//  Bridging-Header.h
//  chat_app
//
//  Created by 김민수 on 2018. 5. 21..
//  Copyright © 2018년 김민수. All rights reserved.
//

#ifndef Bridging_Header_h
#define Bridging_Header_h
#import <JSQMessagesViewController/JSQMessages.h>

#endif /* Bridging_Header_h */
